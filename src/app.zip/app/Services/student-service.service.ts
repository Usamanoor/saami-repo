import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StudentServiceService {

  baseUrl = environment.baseUrl;
  constructor(public http: HttpClient) { }


  public getStudents():Observable<any>{
    return this.http.get(this.baseUrl+"students");
  }

  public postStudent(obj):Observable<any>{
    return this.http.post(this.baseUrl+"students",obj)
  }

  public newDate(){
    return new Date();
  }
}
