import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { StudentServiceService } from '../Services/student-service.service';
import { Student } from './student';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  studentObj = new Student(); 
 

  student = new FormGroup({
    fname : new FormControl('',[Validators.required]),
    lname : new FormControl('',[Validators.required]),
    gender : new FormControl('',[Validators.required]),
    email : new FormControl('',[Validators.required]),
    phone : new FormControl([Validators.required]),
    code : new FormControl('',[Validators.required]),
    address : new FormControl('', [Validators.required]),
    class : new FormControl('',[Validators.required]),
    section : new FormControl('',[Validators.required])
    
  });

  constructor(private myService: StudentServiceService) { }

  ngOnInit(): void {
    this.getData();
  }

  handleSave() {
    console.log(this.student.value);
    alert('form submited!');
    
  }

  postData(){
    this.myService.postStudent(this.studentObj).subscribe(response=>{

    })
  }

  getData(){
    this.myService.getStudents().subscribe(response => {
      console.log("--> " + response);
    })
  }

  onSubmit(){
    
  }

}
